from pathlib import Path
import json,hashlib,zipfile
from PIL import Image
D=Path(__file__).resolve().parents[1];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();report=json.loads((D/'Evidence/v9-review-validation.json').read_text());assert report['lab_sha256']==sha(D/'Avatar-Lab.html');report['approval']='APPROVED_BY_USER: так публікуй';report['approved_preview_sha256']=sha(D/'Gallery/restored-upper-body-no-weapon.png');(D/'Evidence/v9-review-validation.json').write_text(json.dumps(report,indent=2))
Image.open(D/'Gallery/avatar-restored-107.png').convert('RGB').crop((115,170,820,810)).save(D/'Gallery/restored-upper-body-wide.png')
readme='''ПАЛАТА404 · RIFLE V9 · 28.10.2026

Розпакуйте архів і відкрийте Avatar-Lab.html у Chrome / Edge з WebGL. Файл самодостатній: попередні версії та встановлення не потрібні. Gallery.html містить схвалений ширший кадр без зброї та повний вигляд на107/110%.

У v9 відновлено стик правого плеча з тулубом зі збережених суміщених пікселів шкіри; закрито зайвий білий просвіт та згладжено нижній перехід у контур біцепса. Користувач схвалив фінальний варіант і публікацію. Кисть і пальці піксельно незмінні від v8, включно з останньою правкою одного пікселя. Рух біцепса, посадка обох кистей та автомат збережені від v8. Нової генерації немає.

After — поточні повні шари941×1672 RGBA; Render — поточні похідні шари для анімації; Weapon — незмінений оригінал та окрема непрозора похідна. Before — історичні джерела v3, не попередня v8. Порівняння V8 BEFORE / RESTORED у Gallery використовують справжню попередню v8.

Masks/right-v9-* — зміни від v8; source-protect — захист поза фактичною правкою. right-rifle-front-alpha та rear-alpha у сумі точно відтворюють альфу поточної повної правої руки. Решта масок — історія попередніх правок; не застосовувати їх повторно автоматично.

Перевірено 64 растрові фази стику:107/110%, амплітуда1×/3×, світлий і темний фон у прев’ю; додатково6 фаз нижнього кінця відновлення. Підтверджено відсутність видалення альфи порівняно з v8, незмінність кисті й пальців та коду руху. Повна перевірка руху v8 збережена як історичне свідчення; для v9 повторно перевірено саме змінений стик.

Це ізольований чоловічий Avatar Lab; основну гру/live та інші пози не змінено. Tools/build-trial.py потребує вихідного avatar-core commit069ff32c837a4947d63a5706a9298f6fc8ecb7fa; restore-v9.py використовує робочі джерела v7/v8. Для відкриття готового Avatar-Lab.html ці залежності не потрібні. Source files, актуальні маски, код рендерера та матеріали перевірки включені.
'''
(D/'README-UA.txt').write_text(readme)
html='''<!doctype html><meta charset="utf-8"><title>Rifle v9 — відновлений стик плеча</title><style>body{font:16px Arial;max-width:1000px;margin:24px auto;background:#eee;color:#222}img{max-width:100%;height:auto}figure{margin:24px 0}figcaption{margin:8px 0}</style><h1>Rifle v9</h1><p><a href="Avatar-Lab.html">Відкрити Avatar Lab</a> · <a href="README-UA.txt">Інструкція</a></p>'''
for label,name in [('Схвалений ширший кадр без зброї','restored-upper-body-no-weapon.png'),('Повний вигляд,107%','avatar-restored-107.png'),('Повний вигляд,110%','avatar-restored-110.png'),('Порівняння: v8 ліворуч, відновлення праворуч — вдих','shoulder-light-1000.png'),('Порівняння на темному фоні — видих','shoulder-dark-3000.png')]:html+='<figure><figcaption>'+label+'</figcaption><img src="Gallery/'+name+'"></figure>'
(D/'Gallery.html').write_text(html)
files=[D/'Avatar-Lab.html',D/'Gallery.html',D/'README-UA.txt']
for folder in ['After','Before','Render','Masks','Reference','Weapon','Runtime','Gallery']:files.extend(p for p in (D/folder).rglob('*')if p.is_file()and'__pycache__'not in p.parts)
for name in ['build-trial.py','trial-runtime.js','restore-v9.py','review-v9.py','package-v9.py']:files.append(D/'Tools'/name)
for name in ['v9-restoration.json','v9-review-validation.json','v9-lower-tip-coverage.json','v8-validation.json','v8-source-edits.json','final-single-pixel-refinement.json','trial-registration.json','baseline-trial-registration.json','arap-support-maps.json','shoulder-contact-line.json','left-shoulder-contact-line.json','finger-polygons.json','gap-and-neck-preparation.json']:files.append(D/'Evidence'/name)
manifest={str(p.relative_to(D)):sha(p)for p in files};mp=D/'files-sha256.json';mp.write_text(json.dumps(manifest,indent=2));files.append(mp);out=D.parent/'Palata404-Rifle-Shoulder-Restore-v9-20261028.zip'
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
 for p in files:z.write(p,str(p.relative_to(D)))
with zipfile.ZipFile(out)as z:
 assert z.testzip()is None
 for n,h in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==h,n
summary={'zip':str(out),'bytes':out.stat().st_size,'sha256':sha(out),'files':len(files),'lab_sha256':manifest['Avatar-Lab.html'],'all_file_hashes_and_CRC_verified':True,'approval':report['approval']};(D.parent/'Palata404-Rifle-Shoulder-Restore-v9-20261028-verification.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
