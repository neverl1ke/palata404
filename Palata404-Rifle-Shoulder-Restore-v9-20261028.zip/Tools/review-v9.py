from pathlib import Path
import json,hashlib,base64,io
import numpy as np
from PIL import Image,ImageDraw
from playwright.sync_api import sync_playwright
D=Path(__file__).resolve().parents[1];S=D.parent/'Rifle-Arm-Cleanup-v8-20261028';errors=[];report={'coverage':[]};sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(D/'Tools/trial-runtime.js')==sha(S/'Tools/trial-runtime.js');a=np.array(Image.open(D/'After/02-RIGHT-ARM-CLEANED-941x1672.png'));old=np.array(Image.open(S/'After/02-RIGHT-ARM-CLEANED-941x1672.png'));assert np.array_equal(a[550:],old[550:]);assert np.all(a[:,:,3]>=old[:,:,3]);assert sha(D/'Masks/right-rifle-front-alpha.png')==sha(S/'Masks/right-rifle-front-alpha.png')
with sync_playwright()as p:
 b=p.chromium.launch(args=['--enable-unsafe-swiftshader']);pages=[]
 for root in [S,D]:
  pg=b.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));pg.goto((root/'Avatar-Lab.html').as_uri());pg.wait_for_function('window.avatarTrial?.ready',timeout=120000);pg.evaluate('avatarTrial.state.play=false');pages.append(pg)
 def render(pg,o):
  raw=pg.evaluate('o=>{avatarTrial.render(o);return avatarTrial.canvas.toDataURL().split(",")[1]}',o);return Image.open(io.BytesIO(base64.b64decode(raw)))
 after=pages[1];probe=np.array(json.loads((D/'Evidence/shoulder-contact-line.json').read_text()));probe=probe[(probe[:,1]>=302)&(probe[:,1]<=438)].tolist()
 for amp in [1,3]:
  for scale in [1.07,1.1]:
   for t in [0,500,1000,1500,2000,2500,3000,3500]:
    o={'stage':'After','time':t,'scale':scale,'amplitude':amp,'weaponSwayPx':2 if amp==1 else 5,'weapon':False,'background':'transparent'};im=np.array(render(after,o));points=after.evaluate('ps=>ps.map(p=>avatarTrial.pointOn(avatarTrial.meshSets.After.right,avatarTrial.latest.vertices.right,p))',probe)
    def sample(pt):
     x,y=pt[0]-.5,pt[1]-.5;ix,iy=int(np.floor(x)),int(np.floor(y));fx,fy=x-ix,y-iy;return float(im[iy,ix,3]*(1-fx)*(1-fy)+im[iy,ix+1,3]*fx*(1-fy)+im[iy+1,ix,3]*(1-fx)*fy+im[iy+1,ix+1,3]*fx*fy)
    values=list(map(sample,points));minimum=min(values);assert minimum>=230,(amp,scale,t,minimum,probe[values.index(minimum)]);report['coverage'].append({'amplitude':amp,'scale':scale,'time':t,'min_alpha':minimum})
 print('Shoulder edge coverage passed',flush=True)
 for bg,label in [('#f8f5ed','light'),('#151d25','dark')]:
  for t in [0,1000,3000]:
   opts={'stage':'After','time':t,'scale':1.07,'amplitude':1,'weaponSwayPx':2,'weapon':False,'background':bg};ims=[render(pg,opts)for pg in pages];box=(285,315,370,465);w,h=340,600;out=Image.new('RGB',(680,628),bg);dr=ImageDraw.Draw(out)
   for i,im in enumerate(ims):out.paste(im.crop(box).resize((w,h),Image.Resampling.NEAREST),(w*i,28));dr.text((w*i+5,7),'V8 BEFORE'if i==0 else'RESTORED',fill='black'if label=='light'else'white')
   out.save(D/'Gallery'/f'shoulder-{label}-{t}.png')
 for scale in [1.07,1.1]:
  render(after,{'stage':'After','time':0,'scale':scale,'amplitude':1,'weaponSwayPx':2,'weapon':True,'background':'#f8f5ed'}).save(D/'Gallery'/f'avatar-restored-{round(scale*100)}.png')
 b.close()
assert not errors;report.update({'JS_errors':errors,'source_no_pixels_removed':True,'hand_and_finger_pixels_exact_v8':True,'runtime_motion_exact_v8':True,'lab_sha256':sha(D/'Avatar-Lab.html'),'approval':'PENDING_USER_REVIEW'});q=D/'Evidence/v9-review-validation.json';q.write_text(json.dumps(report,indent=2));print('PASS',report['lab_sha256'],flush=True)
