from pathlib import Path
import json,base64,hashlib,copy
import numpy as np,cv2
from scipy import ndimage as ndi
from PIL import Image
D=Path(__file__).resolve().parents[1];R=Path(__import__('os').environ.get('PALATA_SOURCE_ROOT','/workspace/palata404-avatar-core'));C=R/'avatar-core';W,H=941,1672
# Frozen engine/resources are copied, never changed in the game checkout.
rig=json.loads((C/'rigs/male_rig.json').read_text());cfg=json.loads((C/'male-preview.json').read_text());data={'json':{n:json.loads((C/n).read_text()) for n in ['rigs/male_rig.json','male-preview.json','weapons.json','equipment-weapons.json']},'images':{}};paths=set()
def collect(v):
 if isinstance(v,str) and v.lower().endswith('.png'):paths.add(v)
 elif isinstance(v,dict):
  for x in v.values():collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
collect(data['json'])
def uri(p):return 'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()
for n in sorted(paths):
 p=(C/n).resolve()
 if p.is_file():data['images'][n]=uri(p)
# Source images remain coordinate-exact native941x1672. Both arms are bound at phase0.
line=json.loads((D/'Evidence/shoulder-contact-line.json').read_text());leftLine=json.loads((D/'Evidence/left-shoulder-contact-line.json').read_text());baseline=json.loads((D/'Evidence/baseline-trial-registration.json').read_text());meshes={}
landmarks={'right':{'shoulder':[296,358],'elbow':[216,549],'wrist':[415,597],'grip':[480,615]},'left':{'shoulder':[648,359],'elbow':[710,575],'wrist':[735,679],'grip':[752,708]}}
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
def sd(p,a,b):
 p=np.array(p);a=np.array(a);v=np.array(b)-a;t=np.clip(np.dot(p-a,v)/np.dot(v,v),0,1);return np.linalg.norm(p-a-v*t),t
# Grid shares exact global8px cells across torso and arm, eliminating different interpolation at the pinned join.
for side,bounds in [('right',[160,288,528,664]),('left',[576,264,912,776]),('torso',[312,256,640,736])]:
 xs=list(range(bounds[0]//8*8,(bounds[2]//8+1)*8+1,8));ys=list(range(bounds[1]//8*8,(bounds[3]//8+1)*8+1,8));v=[];v_after=[]
 for y in ys:
  for x in xs:
   if side=='torso':weights=[0,0,0];pin=0
   else:
    lm=landmarks[side];du,tu=sd([x,y],lm['shoulder'],lm['elbow']);df,tf=sd([x,y],lm['elbow'],lm['wrist']);dh,th=sd([x,y],lm['wrist'],lm['grip']);fore=float(smooth((du-df+10)/30));hand=float(smooth((min(du,df)-dh+10)/28));along=((np.array([x,y])-lm['shoulder'])@(np.array(lm['elbow'])-lm['shoulder']))/np.linalg.norm(np.array(lm['elbow'])-lm['shoulder']);root=float(smooth((along-8)/80));root=max(root,float(smooth((du-min(df,dh)+8)/24)));weights=[root,fore,hand]
    dist=min(np.hypot(x-p[0],y-p[1]) for p in (line if side=='right' else leftLine));pin=float(1-smooth((dist-16)/24))
   v.append([x,y,*weights]);v_after.append([x,y,weights[0]*(1-pin),*weights[1:]])
 tri=[];nx=len(xs)
 for iy in range(len(ys)-1):
  for ix in range(nx-1):a=iy*nx+ix;tri.extend([[a,a+1,a+nx],[a+1,a+nx+1,a+nx]])
 meshes[side]={'bounds':[0,0,W,H],'vertices':baseline['mesh'][side]['afterVertices'],'afterVertices':v_after,'triangles':tri}
# Authored individual digit masks; no circular wrist or whole-hand rectangle.
polys=json.loads((D/'Evidence/finger-polygons.json').read_text())['polygons'];front={};beforeFront={}
import shutil
for side in ['right','left']:
 front[side]=uri(D/'Masks'/f'{side}-rifle-front-alpha.png')
 dest=D/'Masks'/f'baseline-{side}-front-alpha.png';assert dest.is_file();beforeFront[side]=uri(dest)
torsoAlpha=np.array(Image.open(D/'After/01-TORSO-REPAIRED-941x1672.png'))[:,:,3];insideDistance=ndi.distance_transform_edt(torsoAlpha>=128);detailWeights=[float(smooth((insideDistance[min(H-1,int(v[1])),min(W-1,int(v[0]))]-16)/24)) for v in meshes['torso']['vertices']]
staticWeights=baseline['torso_static_join_weights']
seamMask=np.array(Image.open(D/'Reference/static-join-source-mask.png'))>0
yy,xx=np.indices((H,W));staticJoin=seamMask&(((yy<330)&(xx>=390)&(xx<=565))|(yy>680));joinDistance=ndi.distance_transform_edt(~staticJoin)
armStatic={side:[float(smooth((joinDistance[min(H-1,int(v[1])),min(W-1,int(v[0]))]-16)/24)) for v in meshes[side]['afterVertices']] for side in ['right','left']}
trial={'supportRetarget':json.loads((D/'Evidence/arap-support-maps.json').read_text()),'renderRoot':uri(D/'Render/shared-torso-shoulder-root.png'),'renderArms':{side:uri(D/'Render'/('left-arm-clean-root-separated.png' if side=='left' else 'right-arm-root-separated.png')) for side in ['right','left']},'armStaticWeights':armStatic,'fingerSelectionMasks':{side:uri(D/'Masks'/f'{side}-rifle-finger-selection.png') for side in ['right','left']},'beforeFrontMasks':beforeFront,'leftContactLine':leftLine,'torsoStaticWeights':staticWeights,'torsoDetail':cfg['chestDetail'],'torsoDetailWeights':detailWeights,'meshes':meshes,'contactLine':line,'landmarks':landmarks,'frontPolygons':polys,'frontMasks':front,'stageImages':{},'static':{stage:uri(D/'After'/name) for stage,name in [('Before','00-PROTECTED-HEAD-LOWER.png'),('After','00-PROTECTED-HEAD-LOWER.png')]},'weapon':uri(C/'assets/weapons/user-ak47-20261026/ak47-runtime-opaque.png'),'weaponMasterSHA256':hashlib.sha256((C/'assets/weapons/user-ak47-20261026/ak47-master.png').read_bytes()).hexdigest()}
for stage in ['Before','After']:
 trial['stageImages'][stage]={key:uri(D/stage/name) for key,name in [('torso','01-TORSO-REPAIRED-941x1672.png'),('right','02-RIGHT-ARM-CLEANED-941x1672.png'),('left','03-LEFT-ARM-anatomical-UNCHANGED.png')]}
modules={n:(D/'Runtime'/n).read_text() for n in ['math.mjs','torso-space.mjs','weapon-controller.mjs','skin.mjs','pose-art.mjs','pose-ownership.mjs','relaxed-melee.mjs','engine.mjs']}
(D/'Evidence/trial-registration.json').write_text(json.dumps({'source_commit':'069ff32c837a4947d63a5706a9298f6fc8ecb7fa','full_canvas':[941,1672],'source_space':'uploaded native time0/scale100, no affine or source image resize','landmarks':landmarks,'landmark_semantics':'visible art landmarks for trial mesh weights/weapon placement only, unchanged game rig joints','weapon_physical_scale100':.4,'pose_held_fixed_across_weapon_scales':True,'runtime_module_sha256':{n:hashlib.sha256(s.encode()).hexdigest() for n,s in modules.items()},'mesh':meshes,'front_polygons':polys,'arm_static_join_weights':armStatic,'left_contact_line':leftLine,'torso_static_join_weights':staticWeights,'torso_detail':{'profile':cfg['chestDetail'],'boundary_distance_px':[16,40],'vertex_weights':detailWeights}},indent=2))
head='''<!doctype html><meta charset="utf-8"><title>Палата404 · Rifle v9 · відновлення плеча</title><style>body{font:15px Arial;background:#eee;color:#222;margin:16px}header{position:sticky;top:0;background:#eee;padding:12px;z-index:2}label{margin-right:14px;display:inline-block}canvas#avatar{width:550px;height:836px;border:1px solid #777}main{display:flex;gap:20px}pre{white-space:pre-wrap;max-width:660px;font-size:12px}input[type=range]{width:240px}</style><header><b>Пробна копія · без змін гри</b><br><label>Шари <select id="stage"><option value="Before">Історичний v3 (не v4)</option><option selected>After</option></select></label><label><input type="checkbox" id="weapon" checked>Окремий АК-47</label><label>Кадр <select id="viewWidth"><option value="1100">Повний предмет ·1100px</option><option value="941">Ігрова межа ·941px</option></select></label><label>Розмір <select id="scale"><option value="1.07" selected>107%</option><option value="1.10">110%</option></select></label><label>Фон <select id="background"><option value="#f8f5ed">Світлий</option><option value="#151d25">Темний</option><option value="transparent">Прозорий</option></select></label><label><input type="checkbox" id="breath" checked>Дихання</label><button id="play">Пауза</button><input type="range" id="phase" min="0" max="4000" step="1" value="0"><button id="download">PNG кадру</button><fieldset><legend>Рух</legend><label>Амплітуда дихання <input id="breathAmplitude" type="range" min="0" max="3" step="0.1" value="1"><output id="breathAmplitudeValue">1.0×</output></label><label>Похитування зброї <input id="weaponSway" type="range" min="0" max="5" step="0.25" value="2"><output id="weaponSwayValue">2 px</output></label><label>Цикл дихання, с <input id="cycleSeconds" type="number" min="0.5" max="20" step="0.1" value="4" style="width:70px"></label><label>Частота, циклів/хв <input id="breathFrequency" type="number" min="3" max="120" step="0.1" value="15" style="width:70px"></label><label>Швидкість відтворення <input id="playbackRate" type="range" min="0.25" max="3" step="0.25" value="1"><output id="playbackRateValue">1×</output></label><button id="resetMotion">Стандартний рух</button><small>Похитування синхронне з диханням. Частота задається при1×; швидкість множить темп усієї анімації.</small></fieldset></header><main><canvas id="avatar" width="941" height="1672"></canvas><div><p>Надані PNG941×1672, поза/масштаб тіла незмінні. Старий рушій обчислює дихання; пробний рендер малює нові шари по corrective mesh. На107/110% опорна рука слідує за цівкою; основна кисть і торс не пересуваються.</p><p>Полотна джерел941×1672 незмінні. Повний огляд1100×1672 додає прозорий простір праворуч без масштабування тіла. Режим941px показує фактичну межу вихідного кадру. Основна посадка зv4 збережена:[454,599], кисть біля спуску зберігає контакт із рукояткою. Проба29°: опорна кисть перенесена до синьої області плавною ARAP-деформацією з нерухомим плечовим стиком і жорсткою кистю. Основна кисть збережена; пахвовий край відновлено зі збережених вихідних пікселів та згладжено. Верх опорної кисті позаду зброї; пальці попереду. У v9 відновлено та згладжено стик правого плеча з тулубом. Біцепс слідує за кісткою плеча без розширення разом із грудьми. Правки кисті й пальців з v8 та посадка зброї збережені. 107/110% — пробні посадки, остаточний розмір не затверджено. Контакт точки не доводить природність обхвату.</p><pre id="status">Завантаження…</pre></div></main>'''
boot="const resources="+json.dumps(data,separators=(',',':'))+";const trial="+json.dumps(trial,separators=(',',':'))+";const moduleSources="+json.dumps(modules,separators=(',',':'))+";\n"
js=(D/'Tools/trial-runtime.js').read_text()
(D/'Avatar-Lab.html').write_text(head+'<script type="module">'+boot+js.replace('</script','<\\/script')+'</script>')
print('Lab bytes', (D/'Avatar-Lab.html').stat().st_size,'engine resource PNGs',len(data['images']))
