from pathlib import Path
import json,hashlib,numpy as np
from PIL import Image
from scipy.interpolate import PchipInterpolator
D=Path(__file__).resolve().parents[1];S=D.parent/'Rifle-Arm-Cleanup-v8-20261028';line=np.array(json.loads((D/'Evidence/shoulder-contact-line.json').read_text()));ys=np.unique(line[:,1]);xs=[np.max(line[line[:,1]==y,0])for y in ys];edge=PchipInterpolator(ys,xs);a=np.array(Image.open(S/'After/02-RIGHT-ARM-CLEANED-941x1672.png'));old=a.copy();ref=np.array(Image.open(S/'Reference/original-control-for-axillary-shadow.png'));r=np.array(Image.open(S/'Render/right-arm-root-separated.png'));prior=r.copy();owner=np.array(Image.open(S/'Masks/right-render-arm-root-owner-cut.png'))>0;reserve=np.zeros(a.shape[:2],bool);originalArm=np.array(Image.open(D.parent/'Rifle-Arm-Gap-v7-20261028/After/02-RIGHT-ARM-CLEANED-941x1672.png'))
tail=PchipInterpolator([458,462,468,474,480,486,492],[333.4,331.4,328.8,326.1,323.2,320.1,317.2])
for y in range(298,493):
 taper=min(1,max(0,(y-298)/12),max(0,(473-y)/24));xedge=float(edge(np.clip(y+.5,ys.min(),ys.max())))
 if y>=435:
  valid=np.where(originalArm[y,300:350,3]>=128)[0]+300;xedge=float(valid.max())+.5 if len(valid)else xedge
 boundary=xedge+3*taper
 if y>=458:boundary=float(tail(min(y+.5,492)))
 for x in range(310,357):
  if ref[y,x,3]<230:continue
  coverage=sum(x+(sx+.5)/8<=(float(tail(min(y+(sy+.5)/8,492))) if y>=458 else boundary)for sx in range(8)for sy in range(8))/64
  if x>boundary+1 or x<min(xedge,boundary)-12:continue
  target=round(min(253,int(ref[y,x,3]))*coverage)
  if target>int(a[y,x,3]):
   if a[y,x,3]==0:a[y,x,:3]=ref[y,x,:3]
   a[y,x,3]=target
  if (owner[y,x] or x>xedge-4)and a[y,x,3]>0:r[y,x]=a[y,x];reserve[y,x]=True
change=np.any(a!=old,axis=2);renderChange=np.any(r!=prior,axis=2);assert np.array_equal(a[550:],old[550:]);assert np.all(a[:,:,3]>=old[:,:,3]);assert np.array_equal(a[~change],old[~change])
def save(path,arr):
 path.unlink(missing_ok=True);Image.fromarray(arr.astype('uint8')).save(path)
save(D/'After/02-RIGHT-ARM-CLEANED-941x1672.png',a);save(D/'Render/right-arm-root-separated.png',r)
front=np.array(Image.open(S/'Masks/right-rifle-front-alpha.png'));rear=a[:,:,3].astype(int)-front.astype(int);assert np.min(rear)>=0;save(D/'Masks/right-rifle-rear-alpha.png',rear)
rearIm=a.copy();rearIm[:,:,3]=rear;rearIm[rear==0]=0;save(D/'Render/right-rear-reference.png',rearIm)
for name,mask in [('right-v9-shoulder-restored-source.png',change),('right-v9-shoulder-render-reserve.png',renderChange),('right-v9-source-protect.png',~change)]:save(D/'Masks'/name,mask*255)
report={'source_pixels_restored':int(change.sum()),'render_pixels_restored':int(renderChange.sum()),'source_bbox_exclusive':Image.fromarray(change).getbbox(),'donor':'Reference/original-control-for-axillary-shadow.png','method':'registered existing skin restored along shoulder seam; upper shoulder overlap and an8x8 antialiased PCHIP lower contour joining the existing biceps edge smoothly; no new generation','no_alpha_removed':True,'all_fingers_source_y550plus_exact_v8':True,'runtime_and_rigid_biceps_motion_unchanged_v8':True};p=D/'Evidence/v9-restoration.json';p.unlink(missing_ok=True);p.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
