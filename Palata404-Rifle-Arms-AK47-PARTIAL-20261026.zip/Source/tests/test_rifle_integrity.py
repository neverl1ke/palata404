"""Rifle-only scope, protected accepted grips and reproducible arm surfaces."""
from pathlib import Path
import json,subprocess,hashlib,unittest
import numpy as np,cv2
from PIL import Image
from scipy import ndimage as ndi
R=Path(__file__).resolve().parents[1];C=R/'avatar-core';D=R/'review/rifle-arm-integrity';BASE='53d42b0'
def old(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
def image(p):return np.array(Image.open(p).convert('RGBA'))
class RifleIntegrityTests(unittest.TestCase):
 def test_approved_bases_rigs_and_other_gameplay_unchanged(self):
  for p in ['base_male.png','base_female.png','avatar-core/rigs/male_rig.json','avatar-core/rigs/female_rig.json','avatar-core/skin.mjs','avatar-core/weapon-controller.mjs','avatar-core/relaxed-melee.mjs','script.js','wardrobe.js','paper-doll-data.js']:
   self.assertEqual(hashlib.sha256((R/p).read_bytes()).hexdigest(),hashlib.sha256(old(p)).hexdigest(),p)
 def test_existing_art_pngs_not_overwritten(self):
  paths=subprocess.check_output(['git','diff','--name-status',BASE,'--','*.png'],cwd=R,text=True).splitlines()
  self.assertFalse([p for p in paths if not p.startswith('A\t')],paths)
 def test_only_rifle_configuration_fields_changed(self):
  for g in ['male','female']:
   a=json.loads(old(f'avatar-core/{g}-preview.json'));b=json.loads((C/f'{g}-preview.json').read_text())
   for d in [a,b]:
    for side in ['right','left']:
     d.get('poseArtCompleteSurfaces',{}).pop('rifle-'+side,None)
     for prefix in ['art-','art-front-']:d.get('poseArtSurfaces',{}).pop(prefix+'rifle-'+side,None)
     d.get('poseMeshExtensions',{}).pop('rifle-'+side,None)
    d.get('poseTorsoSurfaces',{}).pop('rifle',None)
   self.assertEqual(a,b,g)
 def test_accepted_melee_grips_remain_byte_exact(self):
  subprocess.run(['python','tools/check-approved-grips.py'],cwd=R,check=True,capture_output=True)
 def test_reexport_is_byte_deterministic(self):
  paths=[p for g in ['male','female'] for p in (C/f'assets/{g}/rifle-arm-integrity').glob('*.png')];before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
  for script in ['prepare-rifle-integrity.py','prepare-rifle-arm-art.py','prepare-user-ak47.py']:subprocess.run(['python','tools/'+script],cwd=R,check=True,capture_output=True)
  self.assertEqual(before,{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
 def test_complete_surfaces_are_covered_and_have_no_remote_skin_islands(self):
  for g in ['male','female']:
   cfg=json.loads((C/f'{g}-preview.json').read_text());rig=json.loads((C/f'rigs/{g}_rig.json').read_text())
   for side in ['right','left']:
    art=rig['poseArt']['rifle'][side];a=image(C/cfg['poseArtCompleteSurfaces']['rifle-'+side]);full=np.zeros((1672,941,4),np.uint8)
    if g=='male':x,y,x1,y1=art['mesh']['bounds'];self.assertEqual(list(a.shape[:2]),[y1-y,x1-x]);full[y:y1,x:x1]=a
    else:full=a
    mesh=np.zeros((1672,941),np.uint8);v=np.array(art['mesh']['vertices'])
    for t in art['mesh']['triangles']+cfg.get('poseMeshExtensions',{}).get('rifle-'+side,[]):cv2.fillConvexPoly(mesh,np.rint(v[t,:2]).astype('int32'),255)
    self.assertFalse(np.any((full[:,:,3]>=128)&(cv2.dilate(mesh,np.ones((3,3),np.uint8))==0)),(g,side))
    labels,n=ndi.label(a[:,:,3]>0,np.ones((3,3)));sizes=np.bincount(labels.ravel());sizes[0]=0
    if n>1:self.assertLessEqual(int(np.sum(sizes)-sizes.max()),20,(g,side,'detached material',sizes.tolist()))
 def test_original_user_AK47_and_other_weapon_definitions_preserved(self):
  catalog=json.loads((C/'equipment-weapons.json').read_text());before=json.loads(old('avatar-core/equipment-weapons.json'))
  self.assertEqual(catalog['items'][1:],before['items'][1:])
  rifle=catalog['items'][0];self.assertEqual(hashlib.sha256((C/rifle['image']).read_bytes()).hexdigest(),'891939f70b385def634c127f1999b22db92f55a3a6a80a99369fd01623b3104f')
  self.assertEqual(rifle['artStatus'],'COMPLETE')
  for g in ['male','female']:
   self.assertEqual(rifle['attachmentByGender'][g]['scale'],.4)
   self.assertTrue(rifle['attachmentByGender'][g]['previewScaleSupport'])

 def test_AK47_contacts_land_on_original_opaque_material(self):
  rifle=json.loads((C/'equipment-weapons.json').read_text())['items'][0];pixels=image(C/rifle['image'])
  for g in ['male','female']:
   a=rifle['attachmentByGender'][g]
   for x,y in [a['primary'],*a['previewSupportProfiles'].values()]:
    self.assertGreater(int(pixels[y,x,3]),240,(g,x,y))
