"""Pose-owned torso boundary repair using approved base pixels, no new artwork.

Do not replace missing AK-47 or invent hidden hand material. Only eliminate
detached neutral-arm remnants and repair the current torso's perforated matte.
"""
from pathlib import Path
import json
import numpy as np
from scipy import ndimage as ndi
from PIL import Image
R=Path(__file__).resolve().parents[1];C=R/'avatar-core';D=R/'review/rifle-arm-integrity'
def smooth(x):x=np.clip(x,0,1);return x*x*(3-2*x)
records=[]
for g in ['male','female']:
 cfg=json.loads((C/f'{g}-preview.json').read_text());rig=json.loads((C/f'rigs/{g}_rig.json').read_text())
 a=np.array(Image.open(D/f'Sources/{g}-torso.png').convert('RGBA'));out=a.copy();x0,y0,x1,y1=rig['segments']['torso']['bounds']
 base=np.array(Image.open(R/f'base_{g}.png').convert('RGBA'))[y0:y1,x0:x1]
 h,w=a.shape[:2];yy,xx=np.indices((h,w));Y=yy+y0
 left=[];right=[]
 for row in a[:,:,3]:
  ids,n=ndi.label(row>=128)
  if not n:left.append(0);right.append(w);continue
  sizes=np.bincount(ids);sizes[0]=0;xs=np.flatnonzero(ids==sizes.argmax())
  l,r=int(xs[0]),int(xs[-1]);left.append(l+1-row[l]/255);right.append(r+row[r]/255)
 left=np.array(left);right=np.array(right)
 # Trace the actual principal torso run, not disconnected2px tails from a
 # neutral upper arm. Small antialias filtering does not alter breast size.
 l=ndi.gaussian_filter1d(ndi.median_filter(left,5),.8)
 r=ndi.gaussian_filter1d(ndi.median_filter(right,5),.8)
 if g=='female':
  # Near the side of the cup, the old silhouette retained neutral-arm shadow
  # outside the actual fabric edge. Trace existing gray fabric, not a new cup.
  rgb=base[:,:,:3].astype(float)
  fabric=(rgb[:,:,0]<1.2*rgb[:,:,2]+8)&(rgb[:,:,0]<1.2*rgb[:,:,1]+8)&(rgb.mean(2)<105)
  for row in range(h):
   y=row+y0
   if not 410<=y<=480:continue
   xs=np.flatnonzero(fabric[row]&(np.arange(w)+x0>=330)&(np.arange(w)+x0<=395))
   if not len(xs):continue
   target=xs[0]-1.2
   weight=smooth((y-410)/12)*(1-smooth((y-465)/15))
   l[row]+=min(12,max(0,target-l[row]))*weight
  l=ndi.gaussian_filter1d(l,.7)
 start,end=(405,565) if g=='male' else (390,530)
 fade=smooth((Y-start)/14)*(1-smooth((Y-end)/14))
 left_band=(xx<np.maximum(left,l)[:,None]+12)&(xx>np.minimum(left,l)[:,None]-22)
 right_band=(xx>np.minimum(right,r)[:,None]-12)&(xx<np.maximum(right,r)[:,None]+22)
 zone=(left_band|right_band)&(fade>0)
 coverage=np.clip(xx+1-l[:,None],0,1)*np.clip(r[:,None]-xx,0,1)*base[:,:,3]
 out[:,:,3][zone]=np.rint(a[:,:,3][zone]*(1-fade[zone])+coverage[zone]*fade[zone])
 # The artwork already exists in the approved base: restore it exactly where
 # old matting left pinholes/fabric truncations, instead of cloning skin.
 blend=fade*zone
 out[:,:,:3]=np.rint(a[:,:,:3]*(1-blend[:,:,None])+base[:,:,:3]*blend[:,:,None])
 out[out[:,:,3]==0]=0
 folder=C/f'assets/{g}/rifle-arm-integrity';folder.mkdir(exist_ok=True)
 p=folder/'torso.png';Image.fromarray(out).save(p);cfg.setdefault('poseTorsoSurfaces',{})['rifle']=str(p.relative_to(C))
 (C/f'{g}-preview.json').write_text(json.dumps(cfg,indent=2,sort_keys=True)+'\n')
 records.append({'gender':g,'changed_rgba_pixels':int(np.count_nonzero(np.any(a!=out,axis=2))),'source':'approved base + existing torso matte','base_modified':False,'only_pose':'rifle','native_y_range':[start,end+14],'missing_arm_paint_restored':False,'new_weapon_received':False})
(D/'Evidence/torso-export.json').write_text(json.dumps(records,indent=2));print(records)
