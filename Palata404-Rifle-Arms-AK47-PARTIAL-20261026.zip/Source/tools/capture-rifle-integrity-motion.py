"""Record two real Canvas cycles; sample actual hull, ownership and joins.
Native keyframes are lossless. Animated views are explicitly smaller previews.
"""
from pathlib import Path
import argparse,base64,functools,io,json,threading,hashlib
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from PIL import Image
from scipy.spatial import ConvexHull
import numpy as np
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];D=R/'review/rifle-arm-integrity';G=D/'Gallery'
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
rows=[];errors=[];missing=[]
parser=argparse.ArgumentParser();parser.add_argument('--version',choices=['result'],default='result');parser.add_argument('--gender',choices=['male','female','both'],default='both');args=parser.parse_args()
with sync_playwright() as pw:
 browser=pw.chromium.launch()
 for version,root in [('result',R)]:
  if args.version!='both' and version!=args.version:continue
  server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(root)))
  threading.Thread(target=server.serve_forever,daemon=True).start()
  page=browser.new_page(viewport={'width':1440,'height':1800});page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:missing.append(r.url) if r.status>=400 else None)
  page.goto(f'http://127.0.0.1:{server.server_port}/avatar-lab/');page.wait_for_function('window.avatarLab?.ready')
  page.evaluate('()=>{let e=avatarLab.engine;e.pause();e.setOptions({transitionMs:0,weaponPreviewScale:1});Object.assign(e.canvas.style,{width:"941px",height:"1672px",minWidth:0,maxWidth:"none",maxHeight:"none"})}')
  catalog={i['pose']:i for i in json.loads((root/'avatar-core/equipment-weapons.json').read_text())['items'] if i['id']=='gear-aks'}
  for g in ['male','female']:
   if args.gender!='both' and g!=args.gender:continue
   page.evaluate('g=>avatarLab.engine.setGender(g)',g)
   for pose,item in catalog.items():
    im=np.array(Image.open(root/'avatar-core'/item['image']));y,x=np.where(im[:,:,3]>0);hull=np.c_[x,y];hull=hull[ConvexHull(hull).vertices].tolist()
    page.evaluate('id=>avatarLab.engine.equipWeaponItem(id)',item['id'])
    for mode,amp,sway,cycle,rate in [('standard',1,2,4000,1)]+[('stress',2,4,1000,2)]:
     page.evaluate('v=>{let e=avatarLab.engine;e.setOptions({background:"#f8f5ed",breathing:true,amplitude:v[0],weaponSwayPx:v[1],cycleMs:v[2],playbackRate:v[3]});e.setLayerVisible("weapon",true)}',[amp,sway,cycle,rate])
     # 240 intervals/cycle for movement measurements, independent of video FPS.
     metrics=page.evaluate('''v=>{let e=avatarLab.engine,rows=[];for(let i=0;i<=480;i++){e.time=i*v[1]/240;let f=e.compute(),m=f.weapon.matrix;rows.push({t:e.time,elbow:f.arms.right.elbow,wrist:f.arms.right.wrist,primaryError:f.primaryError,supportError:f.supportError,hull:v[0].map(([x,y])=>[m[0]*x+m[2]*y+m[4],m[1]*x+m[3]*y+m[5]])})}return rows}''',[hull,cycle])
     q=np.array([r['hull'] for r in metrics]);mid=(q.max(axis=0)+q.min(axis=0))/2;radius=float(np.linalg.norm(q-mid,axis=2).max())
     frames=[];details=[];axillas=[];elbows=[];step=cycle/40
     for i in range(80):
      t=i*step
      page.evaluate('t=>{let e=avatarLab.engine;e.time=t;e.render()}',t)
      native=Image.open(io.BytesIO(base64.b64decode(page.evaluate('avatarLab.engine.canvas.toDataURL().split(",")[1]')))).convert('RGB')
      frames.append(native.resize((360,640),Image.Resampling.LANCZOS))
      crop=(330,540,780,810)
      details.append(native.crop(crop))
      if version=='result':
       axillas.append(native.crop((275,330,415,565) if g=='male' else (285,340,395,540)))
       elbows.append(native.crop((200,520,320,730) if g=='male' else (215,480,335,690)))
      if version=='result' and mode=='stress' and i in [0,10,20,30,40]:
       native.save(G/f'stress-{g}-{pose}-{i//10*25}-True.png')
       page.evaluate('avatarLab.engine.setLayerVisible("weapon",false)')
       (G/f'stress-{g}-{pose}-{i//10*25}-False.png').write_bytes(base64.b64decode(page.evaluate('avatarLab.engine.canvas.toDataURL().split(",")[1]')))
       page.evaluate('avatarLab.engine.setLayerVisible("weapon",true)')
     duration=[100]*80 if mode=='standard' else [12,13]*40
     for suffix,sequence in [('cycle',frames),('grip-cycle',details)]:
      sequence[0].save(G/f'{version}-{g}-{pose}-{mode}-{suffix}.webp',save_all=True,append_images=sequence[1:],duration=duration,loop=0,quality=95)
     for r in metrics:r.pop('hull')
     row={'version':version,'gender':g,'pose':pose,'mode':mode,'cycleMs':cycle,'playbackRate':rate,'amplitude':amp,'sway':sway,'simulated_cycles':2,'video_frames':80,'video_duration_ms':sum(duration),'measurement_samples':len(metrics),'native_hull_radius_px':radius,'native_hull_peak_to_peak_axis_px':np.ptp(q,axis=0).max(axis=0).tolist(),'loop_max_error_px':float(np.abs(q[0]-q[-1]).max()),'metrics':metrics,'animation_resolution':[360,640],'native_keyframe_resolution':[941,1672],'weapon_definition':page.evaluate('avatarLab.engine.weapons[avatarLab.engine.pose]'),'catalog_sha256':hashlib.sha256((root/'avatar-core/equipment-weapons.json').read_bytes()).hexdigest()}
     rows.append(row);print(version,g,pose,mode,round(radius,4),'px',flush=True)
  page.close();server.shutdown()
 browser.close()
if (args.version!='both' or args.gender!='both') and (D/'Evidence/two-cycle-motion.json').exists():
 previous=json.loads((D/'Evidence/two-cycle-motion.json').read_text())
 rows=[c for c in previous['cases'] if not ((args.version=='both' or c['version']==args.version) and (args.gender=='both' or c['gender']==args.gender))]+rows
(D/'Evidence/two-cycle-motion.json').write_text(json.dumps({'cases':rows,'js_errors':errors,'http_errors':missing,'physical_device':False},indent=2)+'\n')
assert not errors and not missing,(errors,missing)
