"""User AK47: three support-calibrated scales, phases and two cycles."""
from pathlib import Path
import functools,threading,base64,io,json
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from PIL import Image,ImageDraw
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];D=R/'review/rifle-arm-integrity';G=D/'Gallery';rows=[];errors=[]
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
s=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(R)));threading.Thread(target=s.serve_forever,daemon=True).start()
with sync_playwright() as pw:
 b=pw.chromium.launch();p=b.new_page(viewport={'width':1440,'height':1800});p.on('pageerror',lambda e:errors.append(str(e)));p.goto(f'http://127.0.0.1:{s.server_port}/avatar-lab/');p.wait_for_function('window.avatarLab?.ready');p.evaluate('()=>{let e=avatarLab.engine;e.pause();Object.assign(e.canvas.style,{width:"941px",height:"1672px",minWidth:0,maxWidth:"none",maxHeight:"none"});e.setOptions({breathing:true,amplitude:1,cycleMs:4000,weaponSwayPx:2,transitionMs:0,background:"#f8f5ed"})}')
 for g in ['male','female']:
  p.evaluate('g=>avatarLab.engine.setGender(g)',g);p.evaluate('avatarLab.engine.equipWeaponItem("gear-aks")')
  p.evaluate('avatarLab.engine.setOptions({background:"#f8f5ed"})')
  for k in [.85,1,1.15]:
   row=p.evaluate('''k=>{let e=avatarLab.engine;e.time=0;e.setOptions({weaponPreviewScale:k});e.setLayerVisible('weapon',true);e.render();let f=e.frame,d=e.weapons.rifle,m=f.weapon.matrix,q=d.primary,a=m,sp=f.weapon.supportSource||d.support,actual=[a[0]*sp[0]+a[2]*sp[1]+a[4],a[1]*sp[0]+a[3]*sp[1]+a[5]];return {source:d.image,previewScale:k,actualSupportGap:Math.hypot(actual[0]-f.arms.left.grip[0],actual[1]-f.arms.left.grip[1]),primaryError:f.primaryError,newAK47Received:true,png:e.canvas.toDataURL().split(',')[1]}}''',k)
   Image.open(io.BytesIO(base64.b64decode(row.pop('png')))).save(G/f'new-ak47-{g}-{round(k*100)}.png');row['gender']=g
   row['two_cycles']=p.evaluate('''()=>{let e=avatarLab.engine,result=[];for(let i=0;i<=480;i++){e.time=i*8000/480;let f=e.compute();result.push({time:e.time,primaryError:f.primaryError,supportError:f.supportError,elbow:f.arms.left.elbow,wrist:f.arms.left.wrist})}return result}''')
   assert max(v['supportError'] for v in row['two_cycles'])<1e-6,(g,k,max(v['supportError'] for v in row['two_cycles']))
   for phase in [0,1000,2000,3000,4000]:
    for visible in [True,False]:
     p.evaluate('v=>{let e=avatarLab.engine;e.time=v[0];e.setLayerVisible("weapon",v[1]);e.render()}',[phase,visible])
     if phase in [0,2000]:
      Image.open(io.BytesIO(base64.b64decode(p.evaluate('avatarLab.engine.canvas.toDataURL().split(",")[1]')))).crop((140,285,920,820)).save(G/f'ak47-{g}-{round(k*100)}-{phase}-{visible}.webp',lossless=True)
   rows.append(row)
  for color,name in [('#fff','white'),('#777','gray'),('#000','black'),('#0f0','green')]:
   p.evaluate('c=>{let e=avatarLab.engine;e.time=0;e.setOptions({weaponPreviewScale:1,background:c});e.setLayerVisible("weapon",false);e.render()}',color)
   Image.open(io.BytesIO(base64.b64decode(p.evaluate('avatarLab.engine.canvas.toDataURL().split(",")[1]')))).save(G/f'hidden-{g}-{name}.png')
 b.close()
s.shutdown();assert not errors; (D/'Evidence/AK47-scale-regression.json').write_text(json.dumps({'cases':rows,'notice':'Original AK47 imported unchanged; support is solved from the scaled item before rendering. Numerical contact does not prove anatomy.','js_errors':errors},indent=2));print('New AK47: 3 scales each gender, 2 cycles and phase renders; 4 hidden backgrounds')
