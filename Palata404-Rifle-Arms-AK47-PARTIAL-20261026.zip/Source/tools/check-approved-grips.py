"""Protect user-approved relaxed-wrap anatomy, foreground and item contract."""
from pathlib import Path
import hashlib,json
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parents[1];C=R/'avatar-core'
D=R/'references/avatar-grips/relaxed-wrap-accepted-20261026'
m=json.loads((D/'manifest.json').read_text());checks=[]
for p,h in m['files'].items():
 assert hashlib.sha256((D/'Snapshot'/p).read_bytes()).hexdigest()==h,('reference altered',p)
for p,h in m['controls'].items():
 assert hashlib.sha256((D/p).read_bytes()).hexdigest()==h,('control altered',p)
# A separately authorized rifle replacement may change the shared catalog.
# Preserve the entire approved knife entry, including attachments and scale.
catalog='avatar-core/equipment-weapons.json'
current=json.loads((R/catalog).read_text());approved=json.loads((D/'Snapshot'/catalog).read_text())
assert next(i for i in current['items'] if i['id']=='gear-knife')==next(i for i in approved['items'] if i['id']=='gear-knife'),'approved knife catalog entry changed'
for p in ['avatar-core/assets/weapons/knife-user-20261025/knife-master.png','avatar-core/assets/weapons/knife-view-20261025/knife-view.png']:
 assert hashlib.sha256((R/p).read_bytes()).hexdigest()==m['files'][p],p
for g,region in m['active_hand_regions'].items():
 cfg=json.loads((C/f'{g}-preview.json').read_text());baseline=json.loads((D/'Snapshot/avatar-core'/f'{g}-preview.json').read_text())
 assert cfg['weapons']['melee']==baseline['weapons']['melee'],g
 profile=cfg['gripProfiles']['relaxed-wrap'];old=baseline['gripProfiles']['relaxed-wrap']
 assert {k:v for k,v in profile.items() if k!='completeHandImage'}=={k:v for k,v in old.items() if k!='completeHandImage'},g
 assert hashlib.sha256((C/profile['frontImage']).read_bytes()).hexdigest()==region['frontImage_SHA256'],g
 a=np.array(Image.open(C/cfg['poseArtCompleteSurfaces']['melee-right']).convert('RGBA'))
 assert hashlib.sha256(a[region['rowInBitmap']:].tobytes()).hexdigest()==region['decodedRGBA_SHA256'],('full hand changed',g)
 for p in [f'avatar-core/rigs/{g}_rig.json']:
  assert hashlib.sha256((R/p).read_bytes()).hexdigest()==m['files'][p],p
 checks.append({'gender':g,'approved_hand_RGBA_exact':True,'foreground_PNG_exact':True,'attachment_exact':True,'rig_exact':True})
print(json.dumps({'approval':'both grips accepted; female arm NOT accepted','reference_source':m['source_commit'],'checks':checks,'knife_master_view_catalog_exact':True},indent=2))
