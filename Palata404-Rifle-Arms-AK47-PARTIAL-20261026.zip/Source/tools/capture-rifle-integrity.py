"""Native real-renderer evidence. Before capture must precede runtime edits."""
from pathlib import Path
import argparse,base64,functools,json,threading,hashlib,io
import numpy as np
from PIL import Image
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from playwright.sync_api import sync_playwright

R=Path(__file__).resolve().parents[1]
D=R/'review/rifle-arm-integrity'
parser=argparse.ArgumentParser();parser.add_argument('version',choices=['result']);a=parser.parse_args()
class Quiet(SimpleHTTPRequestHandler):
 def log_message(self,*args):pass
server=ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(R)))
threading.Thread(target=server.serve_forever,daemon=True).start()
errors=[];missing=[];rows=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch();page=browser.new_page(viewport={'width':1440,'height':1800})
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('response',lambda r:missing.append(r.url) if r.status>=400 else None)
 page.goto(f'http://127.0.0.1:{server.server_port}/avatar-lab/');page.wait_for_function('window.avatarLab?.ready')
 page.evaluate('''()=>{let e=avatarLab.engine;e.pause();Object.assign(e.canvas.style,{width:'941px',height:'1672px',minWidth:0,maxWidth:'none',maxHeight:'none'});e.setOptions({background:'#f8f5ed',breathing:true,transitionMs:0,weaponPreviewScale:1,amplitude:1,weaponSwayPx:2,cycleMs:4000})}''')
 for g in ['male','female']:
  page.evaluate('g=>avatarLab.engine.setGender(g)',g)
  for pose,item in [('rifle','gear-aks')]:
   page.evaluate('id=>avatarLab.engine.equipWeaponItem(id)',item)
   for t in [0,1000,2000,3000,4000]:
    for visible in ([False] if pose=='idle' else [False,True]):
     page.evaluate('v=>{let e=avatarLab.engine;e.time=v[0];e.setLayerVisible("weapon",v[1]);e.render()}',[t,visible])
     name=f'{a.version}-{g}-{pose}-{t}-{visible}.png'
     (D/'Gallery'/name).write_bytes(base64.b64decode(page.evaluate('avatarLab.engine.canvas.toDataURL().split(",")[1]')))
     rows.append({'file':name,'gender':g,'pose':pose,'time':t,'weapon':visible,'frame':page.evaluate('avatarLab.engine.snapshot()') if t==0 else None})
 protected=[]
 for g in ['male','female']:
  page.evaluate('g=>avatarLab.engine.setGender(g)',g)
  for pose,item in [('idle',None),('melee','gear-knife'),('pistol','gear-pm')]:
   page.evaluate('id=>avatarLab.engine.equipWeaponItem(id)',item)
   for t in [0,1000,2000,3000,4000]:
    for visible in ([False] if pose=='idle' else [False,True]):
     page.evaluate('v=>{let e=avatarLab.engine;e.time=v[0];e.setLayerVisible("weapon",v[1]);e.render()}',[t,visible])
     data=base64.b64decode(page.evaluate('avatarLab.engine.canvas.toDataURL().split(",")[1]'))
     actual=np.array(Image.open(io.BytesIO(data)).convert('RGBA'))
     ref=np.array(Image.open(R/f'review/female-arm-accepted-grips/Gallery/result-{g}-{pose}-{t}-{visible}.png').convert('RGBA'))
     assert np.array_equal(actual,ref),(g,pose,t,visible)
     protected.append(dict(gender=g,pose=pose,time=t,visible=visible,RGBA_exact=True))
  page.evaluate('avatarLab.engine.equipWeaponItem("gear-aks")');page.evaluate('()=>{let e=avatarLab.engine;e.time=1234;e.setLayerVisible("weapon",true);e.render()}');before=page.evaluate('avatarLab.engine.snapshot().frame')
  page.evaluate('avatarLab.engine.setLayerVisible("weapon",false)');assert before==page.evaluate('avatarLab.engine.snapshot().frame')
  page.evaluate('avatarLab.engine.equipWeaponItem(null)');assert page.evaluate('avatarLab.engine.pose')=='idle'
 (D/'Evidence/protected-pose-regression.json').write_text(json.dumps({'cases':protected,'actual_compared_frames':len(protected),'diagnostic_hide_same_pose_time':True,'real_unequip_idle':True},indent=2))
 browser.close()
server.shutdown()
(D/'Evidence'/f'{a.version}-captures.json').write_text(json.dumps({'cases':rows,'js_errors':errors,'http_errors':missing},indent=2)+'\n')
assert not errors and not missing,(errors,missing)
print(a.version,len(rows),'native renders; zero JS/HTTP errors')
