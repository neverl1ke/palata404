"""Sequential final local checks. No push, publication or live-game changes."""
from pathlib import Path
import subprocess,sys
R=Path(__file__).resolve().parents[1];D=R/'review/rifle-arm-integrity/Evidence'
with (D/'source-tests.log').open('w') as f:subprocess.run([sys.executable,'-m','unittest','tests.test_rifle_integrity','-v'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
for args in [['capture-rifle-integrity.py','result'],['capture-rifle-integrity-motion.py','--version','result'],['check-rifle-scales.py']]:subprocess.run([sys.executable,str(R/'tools'/args[0]),*args[1:]],cwd=R,check=True)
