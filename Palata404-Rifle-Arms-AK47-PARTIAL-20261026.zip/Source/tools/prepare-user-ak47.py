"""Reapply original received AK47 and calibrated contacts after older exporters."""
from pathlib import Path
import hashlib,json
from PIL import Image
import numpy as np
R=Path(__file__).resolve().parents[1];C=R/'avatar-core';P=C/'assets/weapons/user-ak47-20261026';master=P/'ak47-master.png'
sha=hashlib.sha256(master.read_bytes()).hexdigest();assert sha=='891939f70b385def634c127f1999b22db92f55a3a6a80a99369fd01623b3104f','Never replace the user master'
im=Image.open(master);assert im.mode=='RGBA' and im.size==(1774,887)
thumb=im.copy();thumb.thumbnail((320,160));thumb.save(P/'ak47-thumb.png')
path=C/'equipment-weapons.json';catalog=json.loads(path.read_text());rifle=next(i for i in catalog['items'] if i['id']=='gear-aks')
rifle.update(image=str(master.relative_to(C)),thumbnail=str((P/'ak47-thumb.png').relative_to(C)),artStatus='COMPLETE',limitation='Original user AK-47 PNG, unchanged master. Rifle arm anatomy remains PARTIAL pending artistic approval.')
for gender in ['male','female']:
 rifle['attachmentByGender'][gender].update(primary=[525,500],support=[1190,380],stock=[40,450],scale=.4,angle=24,previewScaleSupport=True,previewSupportProfiles={'0.85':[1230,380],'1':[1190,380],'1.15':[1130,380]})
path.write_text(json.dumps(catalog,indent=2)+'\n')
a=np.array(im)[:,:,3];record={'original_archive':'АВТОМАТИ.zip','original_member':'АВТОМАТИ/АК-47.png','master_sha256':sha,'size':[1774,887],'mode':'RGBA','master_bytes_unchanged':True,'alpha_min':int(a.min()),'alpha_max':int(a.max()),'transparent_pixels':int((a==0).sum()),'nonzero_alpha_pixels':int((a>0).sum()),'note':'Original partial-alpha edge and material retained; no generated or repainted gun material.'}
(R/'review/rifle-arm-integrity/Evidence/AK47-receipt.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print('Original AK47 and per-size fore-end contacts restored; master unchanged')
