"""Local partial delivery only. Verify the archive and then its extracted Lab."""
from pathlib import Path
import json,hashlib,re,subprocess,zipfile,shutil
R=Path(__file__).resolve().parents[1];D=R/'review/rifle-arm-integrity';Z=R.parent/'Palata404-Rifle-Arms-AK47-PARTIAL-20261026.zip';OUT=R.parent/'rifle-arm-integrity-unpacked'
assert not Z.exists() and not OUT.exists(),'Preserve earlier deliveries'
files={name:D/name for name in ['Avatar-Lab.html','Report.html','Review.pdf','README.md']}
for folder in ['Sources','Evidence']:
 for p in (D/folder).rglob('*'):
  if p.is_file():files[str(p.relative_to(D))]=p
for path in re.findall('src="(Gallery/[^"]+)"',(D/'Report.html').read_text()):files[path]=D/path
for p in (D/'Gallery').glob('result-*-grip-cycle.webp'):files['Gallery/'+p.name]=p
for p in (D/'Gallery').glob('ak47-*.webp'):files['Gallery/'+p.name]=p
for p in [R/'avatar-core/engine.mjs',R/'avatar-core/equipment-weapons.json',R/'avatar-core/male-preview.json',R/'avatar-core/female-preview.json',R/'avatar-lab/lab.mjs']:
 files['Runtime/'+str(p.relative_to(R))]=p
for folder in ['avatar-core/assets/male/rifle-arm-integrity','avatar-core/assets/female/rifle-arm-integrity','avatar-core/assets/weapons/user-ak47-20261026']:
 for p in (R/folder).glob('*.png'):files['Runtime/'+str(p.relative_to(R))]=p
for pattern in ['*rifle*integrity*.py','prepare-rifle-arm-art.py','prepare-user-ak47.py','check-rifle-scales.py','check-approved-grips.py','bundle-avatar-lab.py']:
 for p in (R/'tools').glob(pattern):files['Source/tools/'+p.name]=p
files['Source/tests/test_rifle_integrity.py']=R/'tests/test_rifle_integrity.py'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
extra={'Source/revision.json':json.dumps({'source_commit':head,'base_commit':'53d42b0b08d500c65c66978c076d6baa6cc931fd','branch':'feature/rifle-arm-integrity-53d42b0','art_status':'PARTIAL, not approved','main_merged':False,'published':False,'deployed':False},indent=2).encode()}
extra['Source/code.patch']=subprocess.check_output(['git','diff','53d42b0..HEAD','--','avatar-core','avatar-lab','tools','tests',':(exclude)*.png'],cwd=R)
extra['Source/RESTORE.txt']=b'On a checkout of base_commit, apply code.patch, copy Runtime/avatar-core/assets into avatar-core/assets, and Sources into review/rifle-arm-integrity/Sources. Baseline-rifle-frames.json is immutable calibration for the exporter. Run prepare-rifle-integrity.py, prepare-rifle-arm-art.py, then prepare-user-ak47.py. Other referenced base tools/resources remain in base_commit. Offline Avatar-Lab.html requires no checkout/server.\n'
manifest={name:hashlib.sha256(p.read_bytes()).hexdigest() for name,p in files.items()};manifest.update({name:hashlib.sha256(v).hexdigest() for name,v in extra.items()});extra['SHA256SUMS.json']=json.dumps(manifest,indent=2).encode()
for p in (D/'Gallery').glob('stress-*.png'):p.unlink()
with zipfile.ZipFile(Z,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in files.items():z.write(p,name)
 for name,data in extra.items():z.writestr(name,data)
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h,name
# Only reproducible generated duplicates, never source images or prior delivery.
(D/'Avatar-Lab.html').unlink()
for p in (D/'Gallery').glob('stress-*.png'):p.unlink()
with zipfile.ZipFile(Z) as z:z.extractall(OUT)
for name,h in manifest.items():assert hashlib.sha256((OUT/name).read_bytes()).hexdigest()==h,name
record={'zip':str(Z),'unpacked':str(OUT),'sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),'bytes':Z.stat().st_size,'files':len(manifest)+1,'all_crc_and_unpacked_hashes_exact':True,'source_commit':head,'publication':False}
(R.parent/'Rifle-Arms-AK47-Package-Verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
