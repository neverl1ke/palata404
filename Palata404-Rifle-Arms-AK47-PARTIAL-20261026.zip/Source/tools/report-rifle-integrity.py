"""Review actual rendered pixels; partial artistic result, never an acceptance."""
from pathlib import Path
import json,html
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];D=R/'review/rifle-arm-integrity';G=D/'Gallery'
panels=[]
def compare(name,box,g='female',weapon=False):
 a=Image.open(G/f'before-{g}-rifle-0-{weapon}.png').convert('RGB').crop(box)
 b=Image.open(G/f'result-{g}-rifle-0-{weapon}.png').convert('RGB').crop(box)
 out=Image.new('RGB',(a.width*2+20,a.height+28),'#f8f5ed');out.paste(a,(0,28));out.paste(b,(a.width+20,28));q=ImageDraw.Draw(out);q.text((5,5),'BEFORE / accepted-grips-reference',fill='black');q.text((a.width+25,5),'CANDIDATE / actual renderer',fill='black')
 out.save(G/(name+'.webp'),lossless=True);panels.append((name,name+'.webp'))
for g in ['male','female']:
 compare(g+'-full',(0,0,941,1672),g)
 compare(g+'-with-ak47',(120,280,900,800),g,True)
 compare(g+'-shoulders',(220,285,740,505),g)
 compare(g+'-both-hands',(315,535,745,790),g)
compare('female-elbows-and-forearms',(145,435,755,700))
compare('female-shoulder-apex',(245,285,385,415))
compare('female-axilla',(310,365,405,510))
compare('female-bra-cut',(325,405,405,545))
base_rgba=Image.open(R/'base_female.png').convert('RGBA');base=Image.new('RGBA',base_rgba.size,'#f8f5ed');base.alpha_composite(base_rgba);base=base.convert('RGB');candidate=Image.open(G/'result-female-rifle-0-False.png').convert('RGB')
boxes=[(85,285,360,810),(580,285,855,810)]
out=Image.new('RGB',(1150,560),'#f8f5ed');draw=ImageDraw.Draw(out)
for i,(im,box,title) in enumerate([(base,boxes[0],'BASE right / relaxed'),(candidate,(145,285,420,810),'RIFLE primary / bent'),(base,boxes[1],'BASE left / relaxed'),(candidate,(500,285,775,810),'RIFLE support / bent')]):
 out.paste(im.crop(box),(i*285,30));draw.text((i*285+3,5),title,fill='black')
out.save(G/'female-base-arms-native.webp',lossless=True);panels.append(('Базові руки й зігнуті руки: однаковий native-масштаб; різні перерізи не є виміром однакової товщини','female-base-arms-native.webp'))
rows=[
 ('Цілі руки без предмета','Неповні старі матеріали й межі виділення','Похідні complete/arm/front, локальне відновлення; виправлено захоплення стегна і зріз ліктя','PARTIAL: кисті присутні, але краї та плечові стики ще потребують доведення'),
 ('Жіночі м’язи й об’єм','Старий донор і попередній надмірно масивний варіант','Інтегрований попередній варіант з м’якшим рельєфом обох рук','PARTIAL: точна подібність до base_female не досягнута; художнього приймання немає'),
 ('Тон і фактура','Відмінні джерела та освітлення','Обмежене LAB-узгодження за прилеглим тулубом, збереження деталей','PARTIAL: залишкова відмінність біля плечей і крайових зон'),
 ('Жіноче плече й пахва','Перекриття torso/arm і старий нейтральний край','Похідний rifle torso; альфа-перехід лише над непрозорим тулубом','PARTIAL: верхівки плечей мають видимі злами; внутрішній перехід не завершений'),
 ('Обрізка біля бюстгальтера','Залишок нейтральної руки на torso','Окрема rifle-маска, вилучення нижнього висячого фрагмента','PARTIAL: нижній хвіст прибрано; контакт біля пахви ще відкритий'),
 ('Чоловічі локальні шви','Різні поверхні плеча й руки','Локальний матеріал плеча/зап’ястя без зміни загальної форми','PARTIAL: прямокутна межа під пахвою ще видима'),
 ('Нова модель АК-47','Отримано АВТОМАТИ.zip з оригінальним PNG','Master 1774×887 RGBA імпортовано byte-exact; спільний scale .4, 24°; індивідуальна анатомія','FIXED: оригінал збережений; художнє приймання посадки ще потрібне'),
 ('Опорні хвати 85/100/115','Старий preview scale не переприв’язував опорну кисть','Розмір враховано перед IK лише для нового rifle; кадри та два цикли на кожному масштабі','PARTIAL: числова посадка виправлена; маски пальців і анатомія на всіх масштабах потребують художнього приймання'),
 ('Прийняті хвати ножа й пістолет','Захищені попередні ресурси','Ресурси незмінні; 50 actual-render кадрів pixel-exact','FIXED щодо збереження попередньої поведінки; не нове приймання анатомії'),
 ('Рух і зняття','Контроль attachment не доводить художню якість','2 цикли standard/stress, diagnostic hide та справжній unequip','Точні результати в Evidence; повна історична регресія не виконана')]
table=''.join('<tr>'+''.join('<td>'+html.escape(s)+'</td>' for s in row)+'</tr>' for row in rows)
parts=['<!doctype html><meta charset="utf-8"><title>Палата 404 — rifle candidate, PARTIAL</title><style>body{font:16px system-ui;background:#f8f5ed;color:#222;max-width:1150px;margin:24px auto;padding:16px}img{max-width:100%;height:auto}table{border-collapse:collapse;font-size:13px}td,th{padding:9px;border:1px solid #aaa;vertical-align:top}section{break-before:page}h2{font-size:20px}@media print{body{margin:0}img{max-height:235mm;object-fit:contain}table{font-size:10px}}</style><h1>Палата №404: локальний кандидат пози з автоматом</h1><p><b>PARTIAL / не фінальне художнє приймання.</b> Усі ДО/ПІСЛЯ нижче — реальний Canvas-рендер. ДО містить старий автомат; ПІСЛЯ — отриманий оригінальний АК-47. Master з ZIP збережено без зміни байтів. Main/live не змінені, публікації немає.</p><p>Після пом’якшення рук лишилися злами верхівок плечей, контактні шви та нерівності контуру. Точну відповідність базовим жіночим рукам не завершено: наступну художню редакцію інструмент відхилив (output sexual, request b2532999-12a6-47fe-9eab-0fba57c9e59e). Повтору чи обходу не було. Потрібна локальна художня доробка вихідних шарів дозволеним інструментом.</p><table><tr><th>Пункт</th><th>Причина</th><th>Фактична зміна / доказ</th><th>Залишок</th></tr>'+table+'</table>']
for title,file in panels:parts.append('<section><h2>'+html.escape(title)+'</h2><img src="Gallery/'+file+'"></section>')
parts.append('<section><h2>Два цикли руху: фактичний рендер, зменшений перегляд</h2><p>Standard: 4000 ms, 2 цикли. Stress: 1000 ms, 2 цикли, посилена амплітуда. Числовий збіг контакту не підтверджує природність анатомії.</p>')
for g in ['male','female']:
 for mode in ['standard','stress']:parts.append(f'<p>{g} / {mode}</p><img src="Gallery/result-{g}-rifle-{mode}-cycle.webp">')
parts.append('</section><section><h2>АК-47: 85 / 100 / 115%, фактичний рендер</h2>')
for g in ['male','female']:
 for k in [85,100,115]:
  Image.open(G/f'new-ak47-{g}-{k}.png').save(G/f'ak47-{g}-{k}-full.webp',lossless=True)
  parts.append(f'<p>{g} / {k}%</p><img src="Gallery/ak47-{g}-{k}-full.webp">')
parts.append('</section><section><h2>Фактичні перевірки</h2><p>127 JS-тестів, 8 Python-тестів; 50 захищених кадрів pixel-exact. 20 поточних стандартних кадрів; два цикли normal/stress для обох статей, 481 вимір на режим. 85/100/115%: 481 вимір на два цикли для кожної статі/масштабу, max support error менше 6×10⁻¹³ px. 4 фони: білий, сірий, чорний, зелений. Автономний Lab звірено з RGBA рендера, конфігураціями, матеріалами; unequip→idle і localStorage перевірені. Повну історичну регресію не виконано, старі 8 невдач не оголошено виправленими.</p><p>Незалежні screen-space проби на ділянках пальців під покриттям вихідного PNG виконано в 5 фазах. У time0 збережено RGB з допуском 2: female primary 44/44, support 41/45; male primary 65/67, support 60/69. Решта проб і точні межі хватів не оголошені художньо прийнятими. Evidence/foreground-pixel-probes.json містить усі координати та результати.</p></section>');(D/'Report.html').write_text('\n'.join(parts))
(D/'README.md').write_text('Локальний PARTIAL-кандидат, без публікації/main/deploy. Відкрийте Report.html, Review.pdf та автономний Avatar-Lab.html. Оригінал АК-47 з АВТОМАТИ.zip імпортовано без зміни байтів; три масштаби мають опорну прив’язку. Точна жіноча анатомія щодо base_female лишається OPEN після відмови інструмента. Прийняті хвати ножа захищені. Source/changes.patch застосовується до 53d42b0; Sources містить незмінні до-проходу шари та локальні художні джерела. Детальні результати й невдалі спроби — Evidence/.\n')
print('Actual-render panels and honest partial report written')
