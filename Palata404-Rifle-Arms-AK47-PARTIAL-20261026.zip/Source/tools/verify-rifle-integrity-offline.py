"""Verify offline delivery pixels against actual runtime captures, no network."""
from pathlib import Path
import argparse,base64,io,json,hashlib
from PIL import Image
import numpy as np
from playwright.sync_api import sync_playwright
R=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--directory',type=Path,default=R/'review/rifle-arm-integrity');p.add_argument('--pdf',action='store_true');p.add_argument('--record-output',type=Path);args=p.parse_args();D=args.directory;errors=[];external=[];rows=[]
with sync_playwright() as pw:
 b=pw.chromium.launch();page=b.new_page(viewport={'width':1440,'height':1000})
 page.on('pageerror',lambda e:errors.append(str(e)));page.on('request',lambda r:external.append(r.url) if not r.url.startswith(('file:','data:','blob:')) else None)
 page.goto((D/'Report.html').as_uri(),wait_until='load');assert page.evaluate('Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)')
 if args.pdf:page.pdf(path=str(D/'Review.pdf'),format='A4',print_background=True)
 page.goto((D/'Avatar-Lab.html').as_uri(),wait_until='load',timeout=120000);page.wait_for_function('window.avatarLab?.ready',timeout=120000);page.evaluate('()=>{let e=avatarLab.engine;e.pause();Object.assign(e.canvas.style,{width:"941px",height:"1672px",minWidth:0,maxWidth:"none",maxHeight:"none"});e.setOptions({transitionMs:0,weaponPreviewScale:1})}');saved=page.evaluate('JSON.stringify({...localStorage})')
 for g in ['male','female']:
  page.evaluate('g=>avatarLab.engine.setGender(g)',g);page.evaluate('avatarLab.engine.equipWeaponItem("gear-aks")')
  page.evaluate('()=>{let e=avatarLab.engine;e.time=0;e.setOptions({breathing:true,amplitude:1,cycleMs:4000,weaponSwayPx:2,background:"#f8f5ed"});e.pause()}')
  for visible in [False,True]:
   data=page.evaluate('v=>{let e=avatarLab.engine;e.setLayerVisible("weapon",v);e.render();return e.canvas.toDataURL().split(",")[1]}',visible)
   a=np.array(Image.open(io.BytesIO(base64.b64decode(data))).convert('RGBA'));expected=R/f'review/rifle-arm-integrity/Gallery/result-{g}-rifle-0-{visible}.png';ref=np.array(Image.open(expected).convert('RGBA'));assert np.array_equal(a,ref),(g,visible,'offline pixels differ',a.shape,ref.shape,int(np.count_nonzero(np.any(a!=ref,axis=2))) if a.shape==ref.shape else None,page.evaluate('avatarLab.engine.options'))
   rows.append({'gender':g,'weapon':visible,'native_RGBA_exact':True})
  cfg=json.loads((R/f'avatar-core/{g}-preview.json').read_text());assert page.evaluate('g=>AVATAR_CORE_EMBED.json[g+"-preview.json"]',g)==cfg
  asset=page.evaluate('avatarLab.engine.weapons.rifle.image');data=page.evaluate('k=>AVATAR_CORE_EMBED.images[k]',asset).split(',')[1]
  assert hashlib.sha256(base64.b64decode(data)).hexdigest()=='891939f70b385def634c127f1999b22db92f55a3a6a80a99369fd01623b3104f'
  for key in ['rifle-right','rifle-left']:
   asset=cfg['poseArtCompleteSurfaces'][key];data=page.evaluate('k=>AVATAR_CORE_EMBED.images[k]',asset).split(',')[1];assert hashlib.sha256(base64.b64decode(data)).hexdigest()==hashlib.sha256((R/'avatar-core'/asset).read_bytes()).hexdigest()
  page.evaluate('avatarLab.engine.equipWeaponItem(null)');assert page.evaluate('avatarLab.engine.pose')=='idle'
 assert page.evaluate('JSON.stringify({...localStorage})')==saved
 page.close();b.close()
assert not errors and not external,(errors,external)
(args.record_output or D/'Evidence/offline-verification.json').write_text(json.dumps({'cases':rows,'js_errors':errors,'external_requests':external,'local_storage_unchanged':True,'configs_complete_surfaces_and_AK47_master_hashes_exact':True,'unpacked_directory':str(D)},indent=2)+'\n');print('Offline actual RGBA, both configs/materials, unequip, storage, no external requests: verified')
